#!/bin/bash
if [["$0" == "zsh"]]; then
	echo "./~/cshift/cshift-executable" > ~/.zshrc
elif [["$0" == "bash"]]; then
	echo "./~/cshift/cshift-executable" > ~/.bashrc
elif [["$0" == "sh"]]; then
	echo "./~/cshift/cshift-executable" > ~/.shrc
elif [["$0" == "fish"]]; then
	echo "./~/cshift/chsift-executable" > ~/.config/fish/config.fish
elif [["$0" == "csh" || "$0" == "tcsh"]]; then
	echo "./~/cshift/chsift-executable" > ~/.cshrc
fi
