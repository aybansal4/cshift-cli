#!/bin/bash
echo "./cshift/cshift/executable" > ~/.bashrc
