#!/bin/bash

mv ./cshift_hist ~/.cshift_hist
sudo mv cshift-executable /usr/bin/cshift
sudo echo "/usr/bin/cshift" > /etc/shells
